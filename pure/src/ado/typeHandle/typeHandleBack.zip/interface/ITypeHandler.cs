﻿using System;
using System.Data;

namespace mooSQL.data
{

    /// <summary>
    /// 实现本接口，以自定义参数类型和值解析
    /// </summary>
    public interface ITypeHandler
    {
        /// <summary>
        /// 执行查询前设置参数
        /// </summary>
        /// <param name="parameter">要设置的参数</param>
        /// <param name="value">参数值</param>
        void SetValue(IDbDataParameter parameter, object value);

        /// <summary>
        /// 将一个数据库值转换为指定类型
        /// </summary>
        /// <param name="value">数据库执行</param>
        /// <param name="destinationType">要转换为的类型</param>
        /// <returns>The typed value</returns>
        object Parse(Type destinationType, object value);
    }
    
}
