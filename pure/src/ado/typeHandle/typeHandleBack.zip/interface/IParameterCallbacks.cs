﻿namespace mooSQL.data
{

    /// <summary>
    /// 参数执行后的回调
    /// </summary>
    public interface IParameterCallbacks : IDynamicParameters
    {
        /// <summary>
        /// 当 command 执行后调用
        /// </summary>
        void OnCompleted();
    }
    
}
