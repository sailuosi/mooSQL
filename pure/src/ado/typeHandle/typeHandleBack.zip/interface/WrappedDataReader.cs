﻿using System.Data;

namespace mooSQL.data
{
    /// <summary>
    /// 简单的包装一个 command 和 reader,
    /// 作为属性暴露
    /// </summary>
    public interface IWrappedDataReader : IDataReader
    {
        /// <summary>
        /// Obtain the underlying reader
        /// </summary>
        IDataReader Reader { get; }
        /// <summary>
        /// Obtain the underlying command
        /// </summary>
        IDbCommand Command { get; }
    }
}
