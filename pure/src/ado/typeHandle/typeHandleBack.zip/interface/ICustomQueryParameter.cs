﻿using System.Data;

namespace mooSQL.data
{

    /// <summary>
    /// 自定义DB参数
    /// </summary>
    public interface ICustomQueryParameter
    {
        /// <summary>
        /// 在执行前添加参数
        /// </summary>
        /// <param name="command">The raw command prior to execution</param>
        /// <param name="name">Parameter name</param>
        void AddParameter(IDbCommand command, string name);
    }
    
}
