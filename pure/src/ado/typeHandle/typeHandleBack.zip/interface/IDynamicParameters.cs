﻿using System.Data;

namespace mooSQL.data
{

    /// <summary>
    /// 自定义 db 参数
    /// </summary>
    public interface IDynamicParameters
    {
        /// <summary>
        /// 在执行前添加必要参数
        /// </summary>
        /// <param name="command">The raw command prior to execution</param>
        /// <param name="identity">Information about the query</param>
        void AddParameters(IDbCommand command, Identity identity);
    }
    
}
