﻿using mooSQL.data.context;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mooSQL.data
{
    public static partial class DBConnectExt
    {




        /// <summary>
        /// Execute parameterized SQL that selects a single value.
        /// </summary>
        /// <typeparam name="T">The type to return.</typeparam>
        /// <param name="cnn">The connection to execute on.</param>
        /// <param name="sql">The SQL to execute.</param>
        /// <param name="param">The parameters to use for this command.</param>
        /// <param name="transaction">The transaction to use for this command.</param>
        /// <param name="commandTimeout">Number of seconds before command execution timeout.</param>
        /// <param name="commandType">Is it a stored proc or a batch?</param>
        /// <returns>The first cell returned, as <typeparamref name="T"/>.</returns>
        public static T ExecuteScalar<T>(this SQLBuilder builder)
        {
            return builder.queryAs<T, T>((context,t) =>
            {
                var command =fromConetxt(context);
                return ExecuteScalarImpl<T>(context.session.connection, ref command);
            });
        }

        private static CommandDefinition fromConetxt(ExeContext context) {
            var command = new CommandDefinition(context.cmd.cmdText,null, context.session.transaction, context.cmd.timeout, context.cmd.cmdType, CommandFlags.Buffered);
            return command;
        }

    }
}
